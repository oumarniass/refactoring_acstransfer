var $ = require('jquery');

global.$ = global.jQuery = $;

require('bootstrap');